
<?php 
$title = "imresizer::Upload image";
$description = "Resize image, picture or photos in milimeter(mm), centimeter(cm), inch, pixel and percent(%). 
you can also convert any image to jpg, png, gif, bmp, pdf or tiff. Besides you can perform 
rotate and crop anytime you want.";
$keywords = "keywords";

include_once "template/header.php"; 
?>

<div class="col-sm-8">
	<div id= "centernav">
		<?php include_once "template/uploadTemplate.php"; ?>
	</div>
	<div class="pace"></div>
<!-- </div> -->
<?php include_once "template/footer.php"; ?>
